# Le Jardin des merveilles — version mobile

Cette version est une PWA installable, préparée à partir du jeu existant. Elle utilise les mêmes règles et données de jeu, et peut fonctionner hors ligne après son premier chargement.

## Installation

Les PWA doivent être ouvertes depuis une adresse HTTPS (ou depuis localhost pour le développement). Déposez le contenu de ce dossier sur un hébergement statique HTTPS.

- **Android** : ouvrez l’adresse dans Chrome, puis choisissez « Installer l’application » ou « Ajouter à l’écran d’accueil ».
- **iPhone/iPad** : ouvrez l’adresse dans Safari, touchez Partager, puis « Sur l’écran d’accueil ».

Le manifeste, les icônes et le service worker sont inclus. Le service worker met en cache le jeu pour un usage hors ligne.

## Limites actuelles

La boutique Sponsor reste une démonstration locale : les mises ne sont pas de vrais paiements et ne sont pas partagées entre téléphones. Une enchère réelle exige un serveur sécurisé, des comptes, un prestataire de paiement, le stockage des images et leur modération.
